# Covid_Hilda
Entrenamiento Covid
