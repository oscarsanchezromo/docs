
![FLutter Tensor Flow Tutorial](https://user-images.githubusercontent.com/55942632/73233781-926d3680-41ad-11ea-87ff-fdf7301f2cd2.png)

# Ml With Flutter

Learn how to build a tensorflow model on Techable Machine and then run it on flutter app.
* [Youtube Tutorial](https://www.youtube.com/watch?v=-5kUv47xKy0)

## Show Support
* [Recommend Me On LinkedIn](https://www.linkedin.com/in/lamsanskar/) - I will realy Appriciate this
* Don't forget to star ⭐ the repo 😉, it's FREE.

## Requirements
- Any Operating System (ie. MacOS X, Linux, Windows)
- Android Studio/Visual Studio Code

## Join Us
* [Join Our Facebook Group](https://www.facebook.com/groups/519517995532897/) - I share a lot of value in it

## Credits
* [Blog](https://medium.com/analytics-vidhya/machine-learning-for-flutter-developers-db15c23e3a60)
